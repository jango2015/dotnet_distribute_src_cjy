﻿using BSF.BaseService.NScript.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;

namespace BSF.BaseService.NScript.Compiler
{
    public abstract class BaseCompiler
    {
        public virtual CompilerResult DoCompiler(CompilerInfo compilerInfo)
        {
            return null;
        }
       

        
    }
}
