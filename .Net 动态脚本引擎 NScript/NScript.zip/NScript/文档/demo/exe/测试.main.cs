/*
 * codefiles=codes\a.cs,codes\b.cs; //其他代码文件
 * dllfiles=System.dll,dlls\BSF.dll; //引用的dll
 * compilerlanguage=csharp; //编译语言类型
 */
using System;

using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;


	public class MyMain
	{
	    public string testA()
	    {
	        return new A().test();
	    }
	    public string testB()
	    {
	        return new B().test();
	    }
	    public string testBSF()
	    {
	     	return BSF.Extensions.DBObjectMethodHelper.Tostring("aadfasd打发士大夫大大大");
	    }
		static void Main(string[] args)
	    {
			System.Console.Read();
	    }
	}
	
	
