
using System;
	public class A
	{
	    public string test()
	    {
	        return "aaa1";
	    }
	}
