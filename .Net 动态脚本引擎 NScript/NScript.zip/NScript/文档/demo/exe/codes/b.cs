using System;

	public class B
	{
	    public string test()
	    {
	        return "bbb";
	    }
	}
