
using System;

public class C
{
    public string test()
    {
        return "bbb";
    }
}