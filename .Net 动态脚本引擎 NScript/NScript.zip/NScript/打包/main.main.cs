/*
 * codefiles=a.cs;//其他代码文件
 * dllfiles=System.dll;//引用的dll
 * compilerlanguage=csharp;//编译语言类型
 */
using System;

public class B
{
    public string test()
    {
        return new C().test();
    }
static void Main(string[] args)
        {
System.Console.Read();
        }
}