﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BSF.BaseService.DistributedCache.LoadBalance
{
    public class StartLetterBalance
    {
    }
}
