﻿using BSF.Aop.SystemRuntime;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BSF.Aop.Attributes.Base
{
    public abstract class BaseAopIL
    {
        public virtual void IL(ScanAopInfo info)
        {

        }

       
    }
}
