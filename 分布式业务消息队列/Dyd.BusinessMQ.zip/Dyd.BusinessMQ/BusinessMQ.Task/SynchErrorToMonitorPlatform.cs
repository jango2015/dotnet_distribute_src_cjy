﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BusinessMQ.Task
{
    /// <summary>
    /// 同步错误到监控平台
    /// </summary>
    public class SynchErrorToMonitorPlatform
    {
    }
}
