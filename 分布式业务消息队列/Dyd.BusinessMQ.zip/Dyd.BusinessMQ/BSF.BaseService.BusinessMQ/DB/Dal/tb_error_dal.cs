using System;
using System.Xml.Serialization;
using System.Collections.Generic;
using System.Data;
using System.Text;
using BSF.Extensions;
using BSF.Db;
using BSF.BaseService.DB.Model;

namespace BSF.BaseService.DB.Dal
{
	/*�����Զ����ɹ����Զ�����,��Ҫ������д�Լ��Ĵ��룬����ᱻ�Զ�����Ŷ - ����*/
	public partial class tb_error_dal
    {
        public virtual bool Add(DbConn PubConn, tb_error_model model)
        {

            List<ProcedureParameter> Par = new List<ProcedureParameter>()
                {
					
					//
					new ProcedureParameter("@mqpathid",    model.mqpathid),
					//
					new ProcedureParameter("@mqpath",    model.mqpath),
					//
					new ProcedureParameter("@methodname",    model.methodname),
					//
					new ProcedureParameter("@info",    model.info),
					//
					new ProcedureParameter("@createtime",    model.createtime)   
                };
            int rev = PubConn.ExecuteSql(@"insert into tb_error(mqpathid,mqpath,methodname,info,createtime)
										   values(@mqpathid,@mqpath,@methodname,@info,@createtime)", Par);
            return rev == 1;

        }

        
		public virtual tb_error_model CreateModel(DataRow dr)
        {
            var o = new tb_error_model();
			
			//
			if(dr.Table.Columns.Contains("id"))
			{
				o.id = dr["id"].Tolong();
			}
			//
			if(dr.Table.Columns.Contains("mqpathid"))
			{
				o.mqpathid = dr["mqpathid"].Toint();
			}
			//
			if(dr.Table.Columns.Contains("mqpath"))
			{
				o.mqpath = dr["mqpath"].Tostring();
			}
			//
			if(dr.Table.Columns.Contains("methodname"))
			{
				o.methodname = dr["methodname"].Tostring();
			}
			//
			if(dr.Table.Columns.Contains("info"))
			{
				o.info = dr["info"].Tostring();
			}
			//
			if(dr.Table.Columns.Contains("createtime"))
			{
				o.createtime = dr["createtime"].ToDateTime();
			}
			return o;
        }
    }
}