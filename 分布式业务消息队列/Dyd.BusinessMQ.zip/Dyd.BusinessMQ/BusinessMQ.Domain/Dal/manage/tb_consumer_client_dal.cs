using System;
using System.Xml.Serialization;
using System.Collections.Generic;
using System.Data;
using System.Text;
using BSF.Extensions;
using BSF.Db;
using BusinessMQ.Domain.Model;


namespace BusinessMQ.Domain.Dal
{
	public partial class tb_consumer_client_dal
    {
       
    }
}