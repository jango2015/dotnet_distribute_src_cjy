﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BusinessMQ.Domain.Model.manage
{
    public class tb_producterview_model
    {
        public tb_producter_model ProducterModel;
        public string mqpath;
    }
}
