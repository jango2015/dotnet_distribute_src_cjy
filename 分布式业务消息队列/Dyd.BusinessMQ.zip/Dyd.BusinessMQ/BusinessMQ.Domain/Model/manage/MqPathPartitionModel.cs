﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using BSF.Extensions;

namespace BusinessMQ.Domain.Model.manage
{
    public class MqPathPartitionModel
    {
        public tb_mqpath_partition_model mqpath_partition_model;
        public string mqpath;
        public int maxpartitionindex;
    }
}
