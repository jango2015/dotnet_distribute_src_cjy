﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Monitor.Tasks
{
    class Program
    {
        static void Main(string[] args)
        {
            //Console.ReadLine();
            var Task = new ErrorLogWarningTask();
            //while (true)
            //{
                Task.TestRun();
                //string x = Console.ReadLine();
                //if (x == "b")
                //{
                //    break;
                //}
            //}
        }
    }
}
