﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Monitor.Domain.PlatformManage.Dal;


namespace Monitor.Tasks.Tool
{
    public class GlobalConfig
    {
        public static string MonitorPlatformManageConnectString { get; set; }

    }
}
