﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Monitor.Core
{
    public class CoreGlobalConfig
    {
        public static string PlatformManageConnectString { get; set; }
    }
}
