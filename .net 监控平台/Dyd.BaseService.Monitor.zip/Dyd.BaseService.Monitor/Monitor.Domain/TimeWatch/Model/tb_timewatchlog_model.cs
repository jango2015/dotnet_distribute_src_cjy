﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Monitor.Domain.TimeWatch.Model
{
    public partial class tb_timewatchlog_model
    {
        public string nodenotes { get; set; }
    }
}
