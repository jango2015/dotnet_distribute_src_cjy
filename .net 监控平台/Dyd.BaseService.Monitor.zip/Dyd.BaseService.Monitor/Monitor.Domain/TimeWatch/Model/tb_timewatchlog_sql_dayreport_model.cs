using System;
using System.Xml.Serialization;
using System.Collections.Generic;

namespace Monitor.Domain.TimeWatch.Model
{

    public partial class tb_timewatchlog_sql_dayreport_model
    {
        public string sql { get; set; }
        
    }
}