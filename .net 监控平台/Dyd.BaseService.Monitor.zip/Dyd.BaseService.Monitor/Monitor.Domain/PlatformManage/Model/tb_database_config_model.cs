using System;
using System.Xml.Serialization;
using System.Collections.Generic;

namespace Monitor.Domain.PlatformManage.Model
{
    /// <summary>
    /// tb_database_config Data Structure.
    /// </summary>
    public partial class tb_database_config_model 
    {
    }
}