﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Monitor.Domain.Cluster.Model
{
    public partial class tb_performance_collect_model
    {
        public string nodenotes { get; set; }

        public string serverip { get; set; }

        public string servername { get; set; }
    }
}
