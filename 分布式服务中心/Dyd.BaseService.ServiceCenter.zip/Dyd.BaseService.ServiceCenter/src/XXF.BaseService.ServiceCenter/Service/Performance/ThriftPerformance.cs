﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using XXF.BaseService.ServiceCenter.Service.Provider;

namespace XXF.BaseService.ServiceCenter.Service.Performance
{
    public class ThriftPerformance : BasePerformance
    {
        public ThriftPerformance(ServiceContext context):base(context)
        {
        }
    }
}
