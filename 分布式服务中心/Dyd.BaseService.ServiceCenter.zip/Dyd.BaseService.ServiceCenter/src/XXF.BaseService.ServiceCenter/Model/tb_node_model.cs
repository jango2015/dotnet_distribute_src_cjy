using System;
using System.Xml.Serialization;
using System.Collections.Generic;

namespace XXF.BaseService.ServiceCenter.Model
{
    /// <summary>
    /// tb_node Data Structure.
    /// </summary>
    [Serializable]
    public partial class tb_node_model
    {

        /*�����Զ����ɹ����Զ�����,��Ҫ������д�Լ��Ĵ��룬����ᱻ�Զ�����Ŷ - ����*/

        /// <summary>
        /// 
        /// </summary>
        public int id { get; set; }

        /// <summary>
        /// ����id
        /// </summary>
        public int serviceid { get; set; }

        /// <summary>
        /// ���������ռ䣨����Ψһ��ʾ��
        /// </summary>
        public string servicenamespace { get; set; }

        /// <summary>
        /// �Ựid
        /// </summary>
        public long sessionid { get; set; }

        /// <summary>
        /// ip��ַ
        /// </summary>
        public string ip { get; set; }

        /// <summary>
        /// �˿�
        /// </summary>
        public int port { get; set; }

        /// <summary>
        /// ����״̬
        /// </summary>
        public Byte runstate { get; set; }

        /// <summary>
        /// �ڵ�����ʱ��
        /// </summary>
        public DateTime nodeheartbeattime { get; set; }

        /// <summary>
        /// Ȩ��ֵ
        /// </summary>
        public int boostpercent { get; set; }

        /// <summary>
        /// ��������
        /// </summary>
        public long errorcount { get; set; }

        /// <summary>
        /// ��������
        /// </summary>
        public long connectioncount { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public int visitcount { get; set; }

        /// <summary>
        /// �߳���
        /// </summary>
        public int processthreadcount { get; set; }

        /// <summary>
        /// cpuʱ��
        /// </summary>
        public double processcpuper { get; set; }

        /// <summary>
        /// �ڴ��С
        /// </summary>
        public double memorysize { get; set; }

        /// <summary>
        /// �ļ���С
        /// </summary>
        public double filesize { get; set; }

        /// <summary>
        /// ����ʱ��
        /// </summary>
        public DateTime createtime { get; set; }

        /// <summary>
        /// �ӿڰ汾��
        /// </summary>
        public double interfaceversion { get; set; }

        /// <summary>
        /// Э��json
        /// </summary>
        public String protocoljson { get; set; }
        
    }
}